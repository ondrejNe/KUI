import time
from kuimaze2 import SearchProblem, Map, State
import os
import heapq
from collections import deque


class Agent:

    def __init__(self, environment: SearchProblem):
        self.environment = environment

    def find_path(self) -> list[State]:
        """
        Find a path from the start state to any goal state using BFS with debug prints.
        """
        start_state = self.environment.get_start()
        print(f"Starting BFS from state: {start_state}")

        # Queue for BFS that stores tuples of (state, path_to_state)
        queue = deque([(start_state, [])])

        # Set to keep track of visited states
        visited = set()

        while queue:
            current_state, path = queue.popleft()
            print(f"Exploring state: {current_state} with path: {path}")

            # Return the path if the current state is a goal state
            if self.environment.is_goal(current_state):
                final_path = path + [current_state]
                print(f"Goal reached!!! Final path: {final_path}")
                return final_path

            visited.add(current_state)

            # Explore the neighbors
            for action in self.environment.get_actions(current_state):
                new_state, _ = self.environment.get_transition_result(current_state, action)
                if new_state not in visited:
                    print(f"Adding state to queue: {new_state}")
                    queue.append((new_state, path + [current_state]))
                    visited.add(new_state)

        # If the loop ends without returning, no path was found
        print("No path found to the goal.")
        return []


if __name__ == "__main__":
    # Create a Map instance
    MAP = """
    .S...
    .###.
    ...#G
    """
    map = Map.from_string(MAP)
    # Create an environment as a SearchProblem initialized with the map
    env = SearchProblem(map, graphics=True)
    # Create the agent and find the path
    agent = Agent(env)
    agent.find_path()
